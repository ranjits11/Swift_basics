import UIKit

//struct SomeStructure {
//    static var storedTypeProperty = "Some value."
//    static var computedTypeProperty: Int {
//        return 1
//    }
//}
//enum SomeEnumeration {
//    static var storedTypeProperty = "Some value."
//    static var computedTypeProperty: Int {
//        return 6
//    }
//}
//class SomeClass {
//    static var storedTypeProperty = "Some value."
//    static var computedTypeProperty: Int {
//        return 27
//    }
//    class var overrideableComputedTypeProperty: Int {
//        return 107
//    }
//}
//
//print(SomeStructure.storedTypeProperty)

//SomeStructure.storedTypeProperty = "Another value."
//print(SomeStructure.storedTypeProperty)

//print(SomeEnumeration.computedTypeProperty)

//print(SomeClass.computedTypeProperty)

//struct Username{
//    var name: String
////    func change() {
////        name = "anonymous"
////    }
//    mutating func change() {
//        name = "anonymous"
//    }
//}
//var user = Username(name: "ed")
//user.change()
//print(user.name)

//struct Point {
//    var x = 0.0
//    func iAmXnY(x: Double) -> Bool{
//        return self.x > x
//    }
//}
////Here x is method parameter and self.x is for instance property
//var point = Point(x: 5)
//print(point.iAmXnY(x: 4))

//struct Point {
//    var x = 0.0
//    mutating func moveBy(deltaX: Double){
//        x += deltaX
//    }
//}
//var point = Point(x: 3.2)
//point.moveBy(deltaX: 2)
//print(point.x)
//let point2 = Point(x: 2.1)
//point2.moveBy(deltaX: 2)
//print(point2.x)

//struct Point {
//    var x = 0.0, y = 0.0
//    mutating func moveBy(x deltaX: Double, y deltaY: Double) {
//        self = Point(x: x + deltaX, y: y + deltaY)
//    }
//}
//var somePoint = Point(x: 1.0, y: 1.0)
//somePoint.moveBy(x: 2.0, y: 3.0)
//print("The point is now at (\(somePoint.x), \(somePoint.y))")

//enum TriPod {
//    case low, high, off
//    mutating func next(){
//        switch self {
//        case .off:
//            self = .low
//        case .low:
//            self = .high
//        case .high:
//            self = .off
//        }
//    }
//}
//var currState = TriPod.low
//print(currState)
//currState.next()
//print(currState)
//currState.next()
//print(currState)

//struct LevelTracker {
//    static var highestUnlockedLevel = 1
//    var currentLevel = 1
//    
//    static func unlock(_ level: Int) {
//        if level > highestUnlockedLevel { highestUnlockedLevel = level }
//    }
//    
//    static func isUnlocked(_ level: Int) -> Bool {
//        return level <= highestUnlockedLevel
//    }
//    
//    @discardableResult
//    mutating func advance(to level: Int) -> Bool {
//        if LevelTracker.isUnlocked(level) {
//            currentLevel = level
//            return true
//        } else {
//            return false
//        }
//    }
//}
