import UIKit

var set = Set<String>()
set = ["ranjeet","mahela","ranjeet","singh"]
var fav: Set<String> = ["ranjeet","mahela","ranjeet","singh"]
var favG: Set = ["ranjeet","mahela","ranjeet","singh"]
var ints: Set = [1,3,7,7,7,3,5,9]
var evens: Set = [0,2,4,6,8,10]
var prime: Set = [2,3,5,7]
print(fav, set, favG)
print(ints, ints.count)
print(favG.contains("ranjeet"))
var removed = favG.remove("ranjeet")!
print(removed)
for g in favG {
    print("\(g)")
}
print(favG.sorted(), ints.sorted())
print(ints.union(evens).sorted())
print(ints.intersection(prime).sorted())
print(ints.subtracting(prime).sorted())
print(ints.symmetricDifference(prime).sorted())
