import UIKit

//struct Person {
//    var name: String
//    var style: String{
//        willSet {
//            print("I am changing from \(style) to \(newValue)")
//        }
//        didSet {
//            print("I just changed from \(oldValue) to \(style)")
//        }
//    }
//}
//
//var Virat = Person(name: "Virat", style: "50-50")
//Virat.style = "T20"

//class DataImporter {
//    /*
//    DataImporter is a class to import data from an external file.
//    The class is assumed to take a nontrivial amount of time to initialize.
//    */
//    var filename = "data.txt"
//    // the DataImporter class would provide data importing functionality here
//}
//
//
//class DataManager {
//    lazy var importer = DataImporter()
//    var data: [String] = []
//    // the DataManager class would provide data management functionality here
//}
//
//let manager = DataManager()
//manager.data.append("Some data")
//manager.data.append("Some more data")
//
//print(manager.importer.filename)
//
//struct LoanCal {
//    var amt: Int
//    var interest: Int
//    var year: Int
//    var SI: Int {
//        get {
//            return (amt * interest * year ) / 100
//        }
//    }
//}

//let loan = LoanCal(amt: 20000, interest: 10, year: 5)
//print(loan.SI)
//
//struct Circle {
//    var radius: Double
//    var area: Double {
//        get {
//            return radius * radius * Double.pi
//        }
//        set {
//            radius = sqrt(newValue / Double.pi)
//        }
//    }
//}
//var c1 = Circle(radius: 2.0)
//print("area \(c1.area)")
//c1.area = 12.56
//print("radius \(c1.radius)")

//class StepCounter {
//    var totalSteps: Int = 0 {
//        willSet {
//            print("About to set totalSteps to \(newValue)")
//        }
//        didSet {
//                print("Added \(totalSteps - oldValue) more steps")
//        }
//    }
//}
//let stepCounter = StepCounter()
//stepCounter.totalSteps = 200
//stepCounter.totalSteps = 360
//stepCounter.totalSteps = 896
//
//@propertyWrapper
//struct lessThan12 {
//    private var num = 0
//    var wrappedValue: Int{
//        get { return num }
//        set { num = min(newValue, 12) }
//    }
//}
//
//struct Rect {
//    @lessThan12 var height: Int
//    @lessThan12 var width: Int
//}
//
//var rectangle = Rect()
//rectangle.height = 11
//rectangle.width = 30
//print("Height: \(rectangle.height) \nWidth: \(rectangle.width)")
//
//@propertyWrapper
//struct SmallNumber {
//    var maxi: Int
//    var num: Int
//    var wrappedValue: Int{
//        get { return num }
//        set { num = min(newValue, maxi) }
//    }
//    init() {
//        maxi = 12
//        num = 0
//    }
//    init(wrappedValue: Int){
//        maxi = 12
//        num = min(wrappedValue, maxi)
//    }
//    init(wrappedValue: Int, maxi: Int){
//        self.maxi = maxi
//        num = min(wrappedValue, maxi)
//    }
//}

//struct ZeroRect {
//    @SmallNumber var height: Int
//    @SmallNumber var width: Int
//}
//var zeroRect = ZeroRect()
//print(zeroRect.height, zeroRect.width)

//struct UnitRect {
//    @SmallNumber var height: Int = 1
//    @SmallNumber var width: Int = 1
//}
//var unitRect = UnitRect()
//print(unitRect.height, unitRect.width)

//struct Rect {
//    @SmallNumber(wrappedValue: 4, maxi: 45) var height: Int
//    @SmallNumber(wrappedValue: 7, maxi: 3) var width: Int
//}
//var rRect = Rect()
//print(rRect.height, rRect.width)
//
//
//@propertyWrapper
//struct SmallNumber{
//    private var num: Int
//    private(set) var projectedValue: Bool
//    var wrappedValue: Int {
//        get { return num }
//        set {
//            if newValue > 12 {
//                num = 12
//                projectedValue = true
//            } else {
//                num = newValue
//                projectedValue = false
//            }
//        }
//    }
//    init() {
//        self.num = 0
//        self.projectedValue = false
//    }
//}
//struct SomeStructure {
//    @SmallNumber var someNum: Int
//}
//var someStr = SomeStructure()
//someStr.someNum = 40
//print(someStr.$someNum)
//


//struct Person: Equatable{
//    var age = 20
////    var name: String?
//}

//var p1 = Person()
//var p2 = Person()
//print(p1 == p2)
//struct Resolution: Equatable {
//    var width = 0
//    var height = 0
//}
//let someResolution = Resolution()
//let hd = Resolution(width: 1920, height: 1080)
//var cinema = hd
//cinema.width = 2048
//
//if hd == cinema {
//    print("equal")
//}

