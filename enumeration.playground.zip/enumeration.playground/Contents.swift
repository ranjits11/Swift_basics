import UIKit

//func matchStatus(weather: String) -> String? {
//    if weather == "rain" || weather == "snow" {
//        return nil
//    }
//    return "Match will Resume"
//}
//
//let status = matchStatus(weather: "cloud") ?? "Abandoned"
//print(status)
//
//enum weatherType: CaseIterable {
//    case cloud
////    case wind (speed: Int)
//    case sun
//    case rain
//    case snow
//}
//
//func matchStatus(weather: weatherType) -> String? {
//    switch weather {
//    case .cloud, .sun:
//        return "Match Will Resume"
//    case .wind(let speed) where speed < 25:
//        return "Match Will Resume"
//    case .wind:
//        return "Tough Conditions"
//    default:
//        return nil
//    }
//}
//let status = matchStatus(weather: weatherType.wind(speed: 40)) ?? "Abandoned"
//print(status)

//enum Beverage: CaseIterable {
//    case coffee
//    case tea
//    case juice
//}
//for beverage in Beverage.allCases {
//    print(beverage)
//}
//enum Barcode {
//    case upc(Int, Int, Int, Int)
//    case qrCode(String)
//}
//var productBarcode = Barcode.upc(8, 85909, 51226, 3)
//productBarcode = .qrCode("ABCDEFGHIJKLMNOP")
//switch productBarcode {
//case .upc(let numberSystem, let manufacturer, let product, let check):
//    print("UPC: \(numberSystem), \(manufacturer), \(product), \(check).")
//case .qrCode(let productCode):
//    print("QR code: \(productCode).")
//}
//enum ASCIIControlCharacter: String {
//    case tab = "\t"
//    case lineFeed = "\n"
//    case carriageReturn = "\r"
//}
//
//let char = ASCIIControlCharacter.tab
//print("adfaf\(char.rawValue)=afasd")
//print(char)

enum Planet: Int{
    case earth, mercury, venus, mars, jupiter
}
//let value = Planet.mars.rawValue;
//print(value)
//let pPlanet = Planet(rawValue: 2)
//if let pPlanet = Planet(rawValue: 2) {
//    switch pPlanet {
//    case .earth:
//        print("Safe")
//    default:
//        print("not safe")
//    }
//}
//else {
//    print("No planet on desired position")
//}

enum arithExp {
    case num(Int)
    indirect case add(arithExp, arithExp)
    indirect case multiply(arithExp, arithExp)
}
let five = arithExp.num(5)
let six = arithExp.num(6)
let addition = arithExp.add(five,six)
let product = arithExp.multiply(five, six)

func evaluate(_ expression: arithExp) -> Int {
    switch expression {
    case let .num(value):
        return value
    case let .add(left, right):
        return evaluate(left) + evaluate(right)
    case let .multiply(left, right):
        return evaluate(left) * evaluate(right)
    }
}
print(evaluate(product))

