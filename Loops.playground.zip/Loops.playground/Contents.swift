import UIKit

let base = 3
let power = 4
var answer = 1
for _ in 1...power {
    answer *= base
}
print(answer)

let value = 50
for ans in stride(from: 0, to: value, by: 5){
    print(ans)
}
for val in stride(from: 16, through: value, by: 4){
    print(val)
}
let temperatureInCelsius = 30
let freezeWarning = if temperatureInCelsius <= 0 {
    "It's below freezing. Watch for ice!"
} else {
    nil as String?
}
print(freezeWarning)

