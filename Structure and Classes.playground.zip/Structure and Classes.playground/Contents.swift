import UIKit

//struct car {
//    var name: String
//    var model: Int
//    func description() {
//        print("Name of the car is '\(name)' and its a '\(model)' model")
//    }
//}
//let Audi = car(name: "Audi S3", model: 2012)
//let Mercedes = car(name: "Mercedes Benz", model: 2010)
//Audi.description()
//print("\(Audi) \n\(Mercedes)")

class Person: NSObject {
    override func isEqual(_ object: Any?) -> Bool {
        let object1 = object as? Self
        return self.age == object1?.age
    }
    
    var name: String
    var age: Int
    
    init(name:String, age: Int){
        self.name = name
        self.age = age
    }
    func sing(){
        print("lalala")
    }
}

class Person2: Person {
    override func sing() {
        print("la la la ")
    }
}

class Person3: Person {
    var singingStyle: String
    init(name: String, age: Int, singingStyle: String) {
        self.singingStyle = singingStyle
        super.init(name: name, age: age)
    }
    override func sing() {
        print("lala lala lala")
    }
}

var p1 = Person(name: "abc", age: 20)
var p2 = Person2(name: "xyz", age: 20)
var p3 = Person3(name: "pqr", age:40, singingStyle: "Sufi")
print(p1.name)

var p4 = p1
print(p1 == p2)
print(p1 === p4)
//p1.sing()
//p2.sing()
//p3.sing()

//struct Resolution {
//    var width = 0
//    var height = 0
//}
//let hd = Resolution(width: 1920, height: 1080)
//var cinema = hd
//cinema.width = 2048
//print("cinema is now \(cinema.width) pixels wide")
//print("hd is still \(hd.width) pixels wide")
//class VideoMode {
//    var resolution = Resolution()
//    var interlaced = false
//    var frameRate = 0.0
//    var name: String?
//}
//let tenEighty = VideoMode()
//tenEighty.resolution = hd
//tenEighty.interlaced = true
//tenEighty.name = "1080i"
//tenEighty.frameRate = 25.0
//
//let alsoTenEighty = tenEighty
//alsoTenEighty.frameRate = 30.0
//
//if(tenEighty === alsoTenEighty) { print("Both are poining to the same instance") }
//else { print("Jai Siya Raam") }
//
//print("\(tenEighty.frameRate) \n\(alsoTenEighty.frameRate)")

