import UIKit
//distribute, recieve
class Bank {
    static var coinsInBank = 10_000
    static func distribute(coins coinsRequested: Int) -> Int{
        var coinsToLend = min(coinsRequested, coinsInBank)
        coinsInBank -= coinsToLend
        return coinsToLend
    }
    static func recieve(coins: Int){
        coinsInBank += coins
    }
}

//init, win, deinit
class Player {
    var playerCoins: Int
    init(coins: Int){
        playerCoins = Bank.distribute(coins: coins)
    }
    func win(coins: Int){
        playerCoins += Bank.distribute(coins: coins)
    }
    deinit{
        Bank.recieve(coins: playerCoins)
    }
}

var player1: Player? = Player(coins: 100)
print("Player1 have \(player1!.playerCoins) in purse");
print("Bank have \(Bank.coinsInBank) in Bank");

player1?.win(coins: 2000)
print("Player1 have \(player1!.playerCoins) in purse");
print("Bank have \(Bank.coinsInBank) in Bank");

player1 = nil
print("Player1 have left the game");
print("Bank have \(Bank.coinsInBank) in Bank");

