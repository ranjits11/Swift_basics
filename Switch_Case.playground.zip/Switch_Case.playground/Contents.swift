import UIKit

let anotherCharacter: Character = "a"
switch anotherCharacter {
//case "a": // Invalid, the case has an empty body
case "A":
    print("The letter A")
default:
    print("Not the letter A")
}

var value = 29
var message = "The value is "
switch value{
case 29...40:
    message += "less than 40, ";
    fallthrough
case 29...35:
    message += "less than 35, "
    fallthrough
case 29...50:
    message += "less than 50."
default:
    message = "less than 30 "
}
print(message)

let point = (2, 2)
var msg: String?
switch point {
case (0, 0):
    msg = "Origin"
case (let x, 0):
    msg = "on the x-axis with an x value of \(x)"
case (0, let y):
    msg = "on the y-axis with a y value of \(y)"
case let (x, y):
    msg = "(\(x), \(y)) is on x = y line"
default:
    break
}
print(msg!)
