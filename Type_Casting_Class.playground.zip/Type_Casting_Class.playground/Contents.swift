import UIKit

class MovieItem {
    var name: String
    init(name: String){
        self.name = name
    }
}
class Movie: MovieItem {
    var director: String
    init(name: String, director: String) {
        self.director = director
        super.init(name: name)
    }
}
class Song: MovieItem {
    var artist: String
    init(name: String, artist: String){
        self.artist = artist
        super.init(name: name)
    }
}
let library = [
    Movie(name: "Casablanca", director: "Michael Curtiz"),
    Song(name: "Blue Suede Shoes", artist: "Elvis Presley"),
    Movie(name: "Citizen Kane", director: "Orson Welles"),
    Song(name: "The One And Only", artist: "Chesney Hawkes"),
    Song(name: "Never Gonna Give You Up", artist: "Rick Astley")
]
// the type of "library" is inferred to be [MediaItem]

var movieType = 0
var songType = 0
for item in library {
    if item is Movie {
        movieType += 1
    }else if item is Song {
        songType += 1
    }
    
}
//print("Library contains \(movieType) Movies and \(songType) Songs")
for item in library {
    if let movie = item as? Movie {
        print(movie.name,"-->", movie.director)
    }else if let song = item as? Song {
        print(song.name,"-->", song.artist)
    }
    
}
