import UIKit

//Dictionaries
var dica: [String: String] = ["MUM":"CST", "DEL":"IGIA", "BGL":"VKA"]
var dict = ["MUM":"CST", "DEL":"IGIA", "BGL":"VKA", "KOL":"RNTT"]
print(dict["MUM"]!)
print(dict.count)
for (airCode, airName) in dica {
    print("\(airCode): \(airName)")
}
