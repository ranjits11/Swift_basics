import UIKit

//closure
func descen(_ s1: String, _ s2: String) -> Bool{
    return s1 > s2
}

var arr = ["Ruby", "Prag", "Kanye", "Rocky"]

//var descArr = arr.sorted(by: descen)
//{ (<#parameters#>) -> <#return type#> in
//   <#statements#>
//}
//var descArr = arr.sorted(by: { (s1:String, s2: String) -> Bool in return s1 > s2} )
//var descArr = arr.sorted(by: {s1, s2 in s1 > s2 } )
//var descArr = arr.sorted(by: { $0 > $1 } )
var descArr = arr.sorted(by: <)
print(descArr)
