import UIKit

//Write the given structure in such a way that we should be able to:
//pass age to a person from outside
//read age from outside but no explicit writing
//struct Person {
//     private var age: Int
//     init(age: Int){
//         self.age = age
//     }
//    func getter() -> Int {
//        return age
//    }
//    mutating func setter(myAge: Int){
//        age = myAge
//    }
//}
//var p1 = Person(age: 25)
//print(p1.getter())
//p1.setter(myAge: 30)
//print(p1.getter())

public class SomePublicClass {                  // explicitly public class
    public var somePublicProperty = 0            // explicitly public class member
    var someInternalProperty = 0                 // implicitly internal class member
    fileprivate func someFilePrivateMethod() {}  // explicitly file-private class member
    private func somePrivateMethod() {}          // explicitly private class member
}

class SomeInternalClass {                       // implicitly internal class
    var someInternalProperty = 0                 // implicitly internal class member
    fileprivate func someFilePrivateMethod() {}  // explicitly file-private class member
    private func somePrivateMethod() {}          // explicitly private class member
}

fileprivate class SomeFilePrivateClass {        // explicitly file-private class
    func someFilePrivateMethod() {}              // implicitly file-private class member
    private func somePrivateMethod() {}          // explicitly private class member
}

private class SomePrivateClass {                // explicitly private class
    func somePrivateMethod() {}                  // implicitly private class member
}
//private func someFunction() -> (SomeInternalClass, SomePrivateClass) {
//    // function implementation goes here
//}

//public enum CompassPoint {
//    case north
//    case south
//    case east
//    case west
//}

//public class A {
//    fileprivate func someMethod() {}
//}
//
//
//internal class B: A {
//    override internal func someMethod() {}
//}

struct TrackedString {
    private(set) var numberOfEdits = 0
    var value: String = "" {
        didSet {
            numberOfEdits += 1
        }
    }
}
var stringToEdit = TrackedString()
stringToEdit.value = "This string will be tracked."
stringToEdit.value += " This edit will increment numberOfEdits."
stringToEdit.value += " So will this one."
print("The number of edits is \(stringToEdit.numberOfEdits)")

